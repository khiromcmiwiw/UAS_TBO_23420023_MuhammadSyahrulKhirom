# CRUD Codeigniter UAS Teori Bahasa Formal dan Otomata

### Repository ini dibuat untuk memenuhi proyek UAS TBFO

    Nama    : Muhammad Syahrul Khirom
    NIM     : 23420023
    Prodi   : Teknik Informatika 2020 B (Malam)

<h2> Note : </h2>

**Untuk mengakses fitur CRUD klik Products di sidebar sebelah kiri**
